// pages/createGame/createGame.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   prop:['个人赛','团体赛'],
   type:['篮球','足球','羽毛球'],
   form:{
     title:'',
     type:'选择比赛类别',
     field:'',
     num:''
   },
   time:{
     date1:'开始日期',
     time1:'开始时间',
     date2:'结束日期',
     time2:'结束时间',
     date3:'开始日期',
     time3:'结束时间',
   },
   prop_chosen:'选择比赛性质',
   flag:0
  },
  onShow(){
    let arr=new Array(11).fill(false)
    console.log(arr)
    this.setData({flag:arr})
  },
  submit(){
    for(let i of this.data.flag){
      if(!i){
        wx.showToast({
          title: '请填写所有信息',
          icon:'none'
        })
        return;
      }
    }
    let url={
      '个人赛':'/api2/contest/create-standalone-personal',
      '团体赛':'/api2/contest/create-standalone-team'
    }
    let type={
      '羽毛球':'badminton',
      '篮球':'basketball',
      '足球':'soccer'
    }
  let form =this.data.form;
  let time=this.data.time;
  form['display_time_begin']=this.form_time(time.date1,time.time1)
  form['display_time_end']=this.form_time(time.date2,time.time2)
  form['signup_time_end']=this.form_time(time.date3,time.time3)
  form['compete_sides']=parseInt(form.num)
  form['sport_type']=type[form.type]
  delete form['num']
  delete form['field']
  delete form['type']
  console.log(form)
  let app=getApp()
  app.post(
    url[this.data.prop_chosen],
    form
  ).then((res)=>{
    console.log(res)
  })
  },
  form_time(date,time){
    let con=new Date(date+' '+time)
    return con.getTime()
  },

  input(e){
    let key=e.target.dataset.key
    let form=this.data.form
    let data=this.data;
    let index=e.detail.value
    let time=data.time 
    switch(key){
      case 'title': 
        form[key]=e.detail.value
        this.setData({form:form})
        this.mark(0)
        break;  
      case 'prop':
        this.setData({prop_chosen:data.prop[index]})
        this.mark(1)
       break;
       case 'type':
        form[key]=data.type[index]
        this.setData({form:form})
        this.mark(2)
       break;
       case 'field': 
       form[key]=e.detail.value
       this.setData({form:form})
       this.mark(3)
       break;
       case 'num': 
       form[key]=e.detail.value
       this.setData({form:form})
       this.mark(4)
       break;
       case 'start-date': 
       time.date1=e.detail.value
       this.setData({time:time})
       this.mark(5)
       break;
       case 'start-time': 
       time.time1=e.detail.value
       this.setData({time:time})
       this.mark(6)
       break;
       case 'end-date': 
       time.date2=e.detail.value
       this.setData({time:time})
       this.mark(7)
       break;
       case 'end-time': 
       time.time2=e.detail.value
       this.setData({time:time})
       this.mark(8)
       break;
       case 'cut-date': 
       time.date3=e.detail.value
       this.setData({time:time})
       this.mark(9)
       break;
       case 'cut-time': 
       time.time3=e.detail.value
       this.setData({time:time})
       this.mark(10)
       break;
    }
  
  },
  mark(n){
    let arr=this.data.flag;
    arr[n]=true
     this.setData({flag:arr})
  }
})