// pages/teamDetail/teamDetail.js
Page({

      /**
       * 页面的初始数据
       */
      data: {
        team_id: 0,
        name: "string",
        avatar_url: "string",
        sport_type: "篮球",
        introduction: "一个新团队的产生，往往伴随着一个奇特的构思和策划。. 我们孕育着同一个理想、目标，出发点不同但目的一样，年轻的心在这一刻相聚、团结一致、折破风浪，勇敢起航。歪比歪比歪比巴伯",
        create_time: 0,
        dismiss_time: 0,
        members: [{
           userId: 0,
           nickname: "string",
           avatarUrl: "string",
           gender: "string",
           schoolNameShort: "string",
           realName: "string",
           teamRoles: []
          }]

        },

        /**
         * 生命周期函数--监听页面加载
         */
        onLoad: function (options) {

        },

        /**
         * 生命周期函数--监听页面初次渲染完成
         */
        onReady: function () {

        },

        /**
         * 生命周期函数--监听页面显示
         */
        onShow: function () {

        },

        /**
         * 生命周期函数--监听页面隐藏
         */
        onHide: function () {

        },

        /**
         * 生命周期函数--监听页面卸载
         */
        onUnload: function () {

        },

        /**
         * 页面相关事件处理函数--监听用户下拉动作
         */
        onPullDownRefresh: function () {

        },

        /**
         * 页面上拉触底事件的处理函数
         */
        onReachBottom: function () {

        },

        /**
         * 用户点击右上角分享
         */
        onShareAppMessage: function () {

        }
      })