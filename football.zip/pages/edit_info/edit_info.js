// pages/edit_info/edit_info.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    sexPicker: ['男', '女'],
    schoolPicker: ['山东大学千佛山校区', '山东大学软件园校区'],
    sex: 0,
    school: 0,
    name: '散步',
    intro:'',
    avatar:false,
  },
  getInfo() {
    const app = getApp();
    app.post('/api2/user/info', {}).then((res) => {
      console.log(res)
      const data = res.data.data;
      this.setData({
        info:data,
        sex: data.gender === 'male' || data.gender === '' ? 0 : 1,
        school: data.school_id -1,
        name:data.nickname,
        intro:data.introduction,
        avatar:data.avatar_url
      })
    })
  },
  submit(){
   const data =this.data;
   const param = {
     nickname:data.name,
     introduction:data.intro||'',
     sex:data.gender?'female':'male',
     schoolId:Number(data.school)+1,
     avatarUrl:data.avatar
   }
   const app =getApp()
   app.post('/api2/user/info/edit',param).then((res)=>{
     console.log(res)
   })
  },
  getAvatar(){
    const that = this;
    wx.getUserProfile({
      desc: '获取用户头像',
      success: (res) => {
        const {userInfo:{avatarUrl}} = res;
        that.setData({avatar:avatarUrl})
      }
    })
  },
  inputName(e) {
    const value = e.detail.value;
    this.setData({
      name: value
    });
  },
  inputSex(e) {
    const key = e.detail.value;
    this.setData({
      sex: key
    });
  },
  inputIntro(e) {
    const key = e.detail.value;
    this.setData({
      intro: key
    });
  },
  inputSchoold(e) {
    const key = e.detail.value;
    this.setData({
      school: key
    });
  },
  verify(){
    wx.navigateTo({
      url: '/pages/verify/verify',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  return () {

  }
})