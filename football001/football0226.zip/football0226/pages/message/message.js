// pages/message/message.js
const app=getApp()
const { handlePostTeam } = require('../../api/detail.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    done:[],
    not_done:[
      {
        message_id: 12,
        extra: 23,
        title: '扣懒高手1213',
        type: 'team_join_request_approved',
        description: '扣懒高手'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    // this.init()
  },

  // 处理加入队伍申请
  handleTeam(e){
    console.log(e)
    const { requestid, teamid, approved } = e.currentTarget.dataset;

    handlePostTeam({ requestid, teamid, approved: approved === '1'})
      .then(() => {
        const title = approved === '1' ? '接收成功' : '拒绝成功'
        wx.showToast({
          title,
          icon: 'success'
        })
      })
      .catch(() => {
        const title = approved === '1' ? '接收失败' : '拒绝失败'
        wx.showToast({
          title,
          icon: 'error'
        })
      })
  },
  init(){
   app.post('/api2/user/messages',
   {
     page_size:10,
     page:1
   },
   ).then((res)=>{
     console.log(res);
     let list =res.list
     let done=[]
     let not_done=[]
     let set=new Set('team_join_request_approved',
     'team_join_request_denied',
     'team_join_invitation_approved',
     'team_join_invitation_denied'
     )
     for(let i of list){
       if(set.has(i.type)){
         done.push(i)
       }else{
         not_done.push(i)
       }
     } 
   })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})