// pages/verify/verify.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   name:'',
   id:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  inputName(e) {
    const value = e.detail.value;
    this.setData({
      name: value
    });
  },
  inputId(e) {
    const value = e.detail.value;
    this.setData({
      id: value
    });
  },
  submit(){
    const data = this.data;
    const param={
      real_name:data.name,
      identity:data.id
    }
    const app =getApp();
    app.post('/api2/user/verify-people',param).then((res)=>{
      const data = res.data.code;
      wx.showToast({
        title:data?'信息不正确':'验证成功！',
        duration: 1000,
        icon:'none',
        success(){
          setTimeout(()=>{
            wx.navigateBack({
              delta: 1,
            })
          },1000)
        }
      })
    })
  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})