import request from "../utils/request.js"

// 获取队伍信息
// 0-GET
// 1-POST
// 2-PUT
// 3-DELETE
export function getTeamDetail(teamId) {
  return request('/api2/team/' + teamId + '/info', {}, {
    prompt: false
  }, 1);
}

export function getAllTeam(name_query,page_size,page) {
  //获取所有队伍的信息
  return request('/api2/team/search', {name_query:name_query,page_size:page_size,page:page}, {
    prompt: false
  }, 1)
}

export function getGroup(data) {
  //获取所有比赛组的信息
  return request('/api2/contest/search', data, {
    prompt: false
  })
}

export function getContest(name_query,status_query,page_size,page) {
  //获取所有比赛组的信息
  return request('/api2/contest/search', {name_query:name_query,status_query:status_query,page_size:page_size,page:page}, {
    prompt: false
  }, 1)
}

// 获取userId
export function myUserId() {
  //获取所有比赛组的信息
  return request('/api2/user/my-id', {}, {
    prompt: false
  }, 1)
}


// export function getUserList(data) {
//   return request('/api2/team/' + teamId + '/info', data, {
//     prompt: false
//   }, 1);
// }

// getUserList({
//   name: '23',
//   age: 23,
//   token: '23'
// }).then(res => {
//   console.log(res)
// })