// pages/teamDetail/teamDetail.js
import { getTeamDetail } from '../../api/detail'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: "未知",
    team_id: 0,
    name: "山东大学队",
    avatar_url: "cloud://yqbcloud-2g7yaa5q86375ad0.7971-yqbcloud-2g7yaa5q86375ad0-1305025111/icons/sdu_logo.png",
    sport_type: "basketball",
    introduction: "一个新团队的产生，往往伴随着一个奇特的构思和策划。. 我们孕育着同一个理想、目标，出发点不同但目的一样，年轻的心在这一刻相聚、团结一致、折破风浪，勇敢起航。歪比歪比歪比巴伯",
    create_time: 0,
    dismiss_time: 0,
    members: [{
      userId: 0,
      nickname: "string",
      avatarUrl: "cloud://yqbcloud-2g7yaa5q86375ad0.7971-yqbcloud-2g7yaa5q86375ad0-1305025111/icons/sdu_logo.png",
      gender: "string",
      schoolNameShort: "string",
      realName: "string",
      teamRoles: []
    }],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取队伍信息
    // 模拟队伍id是12
    var that = this;
    let teamId = options.teamid
    console.log(teamId)
    getTeamDetail(teamId).then(res => {
      that.setData({
        type : res.sport_type == "basketball"? "篮球" : "足球",
        name : res.name,
        team_id : res.team_id,
        avatar_url : res.avatar_url,
        introduction : res.introduction,
        members : res.members
      })
    })
    wx.removeStorageSync('teamid')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (e) {
    // 获取队伍信息
    // 模拟队伍id是12
    var that = this;
    let teamId = e.teamid
    getTeamDetail(teamId).then(res => {
      that.setData({
        type : res.sport_type == "basketball"? "篮球" : "足球",
        teamname : res.name,
        team_id : res,team_id,
        avatar_url : res.avatar_url,
        introduction : res.introduction,
        members : res.members
      })
    })
    wx.removeStorageSync('teamid')
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})