import { getStandAloneDetail, Join } from "../../api/detail"

// pages/com-standalone/com-standalone.js
Page({

  /**
   * 页面的初始数据
   */

  data:{
  contest_id: 0,
  title: "2号宿舍楼篮球联谊赛",
  cover_url: "string",
  sport_type: "basketball",
  introduction: "爱上踩踩踩踩踩踩哇哇哇哇哇哇哇哇哇哇哇哇哇哇哇哇哇哇哇1ww踩踩踩擦擦撒啊啊啊啊啊",
  status: "string",
  attend_rule: "string",
  compete_sides: 0,
  create_time: 0,
  creator_user_id: 0,
  signup_time_begin: 0,
  signup_time_end: 1646378582,
  display_time_begin: 1646464982,
  display_time_end: 1646378582,
  hidden: true,
  address: "兴隆山篮球场",
  sides: [
   {
      side_id: 0,
      side_data: [
        {
          type: "string",
          content: "string"
        }
      ],
      constraints: [
        {
          type: "string",
          content: "string"
        }
      ],
      users: [
        {
          user_id: 0,
          nickname: "string",
          avatar_url: "string",
          gender: "string",
          school_name_short: "string",
          real_name: "string",
          data: [
            {
              type: "string",
              content: "string"
            }
          ]
        }
      ]
    }
  ]
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var constId = options.constId;
    getStandAloneDetail(constId).then(res => {
      that.setData({
        contest_id : res.contest_id,
        title : res.title,
        sport_type : res.sport_type,
        introduction : res.introduction,
        display_time_begin : res.display_time_begin,
        signup_time_end : signup_time_end,
        sides : res.sides
      })
    })
    
  },
  JoinCom: function(){
    const that = this;
    Join(contest_id, 0).then(res => {
      
    })
  },

  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})