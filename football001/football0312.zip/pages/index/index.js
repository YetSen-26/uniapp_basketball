//首页
const app = getApp()

Page({
  data: {
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: false,
    autoplay: false,
    interval: 2000,
    duration: 500,
    news_list:[{title:'我是体育新闻体育新闻',visited:'150',}],
    show_login:true
  },
  onLoad() {
    let token=app.globalData.token
    if(token){
      this.setData({show_login:false})
    }
  },
  go_create(e){
    wx.navigateTo({
      url: '/pages/createGame/createGame',
    })
  },
  login:function(){
    let app=getApp()
    let that = this;
    
     let gbdata=app.globalData; 
      wx.login({
       success(res){
         console.log(res)
         let code=res.code;
         app.post('/api2/auth/login/wechat-code',{wechat_code:code}).then((e)=>{
           try {
            wx.setStorageSync('token', e.data.data)
          } catch (e) {
            console.log('setTokenErr',e)
           }
           gbdata.token=e.data.data
           that.setData({show_login:false})
           wx.showToast({
             title: '登陆成功',
             icon:'success'
           })
         })
       }
    })
   
  
   },
})
