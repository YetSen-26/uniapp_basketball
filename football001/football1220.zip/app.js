// app.js
App({
  onLaunch() {
    /*
    try {
      wx.setStorageSync('token', 'test2222')
    } catch (e) { }
    */
    //从localStorage中获取token，登陆时注意存储
    wx.getStorage({
      key: 'token',
      success: (res)=>{
           this.globalData.token=res.data
      }
    }) 
  },
  is_login(){
    return Boolean(this.globalData.token)
  },
  post(url,data,header){
    //统一的post请求方法，返回promise
    let localData=this.globalData
    let m_header=header||{};
    m_header['Authorization']=localData.token
    console.log('url:',url)
    console.log('data',data)
    if(url=='/api2/auth/1ogin/wechat-code'){
      m_header={}
    }
    console.log('header',m_header)
    return new Promise((resolve,reject)=>{
      wx.request({
        url: localData.base_URL+url,
        method:'POST',
        header:m_header,  
        data:data,
        success:e=>resolve(e),
        fail:err=>reject(err)
      })
     })
  },
  globalData: {
    //存储必要的用户信息
    userInfo: null,
    base_URL:'https://api.dxsyqb.cn:9999',
    token:''
  }
})
