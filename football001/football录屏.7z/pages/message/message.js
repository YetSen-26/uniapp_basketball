// pages/message/message.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    done:[],
    not_done:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  this.init()
  },
  init(){
   app.post('/api2/user/messages',
   {
     page_size:10,
     page:1
   },
   ).then((res)=>{
     console.log(res);
     let list =res.list
     let done=[]
     let not_done=[]
     let set=new Set('team_join_request_approved',
     'team_join_request_denied',
     'team_join_invitation_approved',
     'team_join_invitation_denied'
     )
     for(let i of list){
       if(set.has(i.type)){
         done.push(i)
       }else{
         not_done.push(i)
       }
     } 
   })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})