// pages/createGame/createGame.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    prop: ['个人赛', '团体赛'],
    type: ['篮球', '足球', '羽毛球'],
    form: {
      title: '',
      type: '选择比赛类别',
      field: '',
      num: ''
    },
    time: {
      date1: '2021年',
      time1: '12-20',
      date2: '结束日期',
      time2: '结束时间',
      date3: '2021年',
      time3: '12-18',
    },
    prop_chosen: '选择比赛性质',
    flag: 0
  },
  onShow() {
    let arr = new Array(11).fill(false)
    console.log(arr)
    this.setData({
      flag: arr
    })
  },

  toContestDetail: function () {
    wx.switchTab({
      url: '../arrangement/arragement',
    })
  },

})