//首页
const app = getApp()

Page({
  data: {
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: false,
    autoplay: false,
    interval: 2000,
    duration: 500,
    news_list: [{
      title: '我是体育新闻体育新闻',
      visited: '150',
    }],
    show_login: true
  },
  onLoad() {
    let token = app.globalData.token
    if (token) {
      this.setData({
        show_login: false
      })
    }
  },
  go_create(e) {
    console.log('in', e)
    wx.navigateTo({
      url: '/pages/createGame/createGame',
    })
  },
  login: function () {
    let app = getApp()
    let gbdata = app.globalData;
    wx.login({
      success(res) {
        let code = res.code;
        app.post('/api2/auth/1ogin/wechat-code', {
          wechat_code: code
        }).then((e) => {
          console.log(e)
        })
      }
    })

  },
})