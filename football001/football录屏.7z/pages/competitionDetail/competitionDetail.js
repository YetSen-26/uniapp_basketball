// pages/competitionDetail/competitionDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    contest_group_id: 0,
    title: "string",
    stage_list: [{
      stage_id: 0,
      title: "string",
      cover_url: "string",
      introduction: "string",
      display_time_begin: 0,
      display_time_end: 0,
      contest_list: [{
        contest_id: 0,
        status: "string",
        attend_rule: "string",
        display_time_begin: 0,
        display_time_end: 0,
        side_preview: [{
          related_to_me: true,
          names: [
            "string"
          ],
          avatars: [
            "string"
          ]
        }],
        related_to_me: true
      }],
      hidden: true
    }],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = JSON.parse(options.id)
    this.setData({
      contest_group_id:id
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})