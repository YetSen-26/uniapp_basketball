const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
// 时间戳转换
function formatDate(inputTime) {
  var date = new Date(inputTime);
  let year = date.getFullYear()
  let month = date.getMonth() + 1
  let day = date.getDay()
  let weekday = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
  return [year, month, day].join('-') + " &emsp; " + weekday[day] + " &emsp; "
};

function formatDateHour(inputTime) {
  var date = new Date(inputTime);
  var h = date.getHours();
  var m = date.getMinutes();
  return [h, m].join(':')
};
// 导出
module.exports = {
  formatDate: formatDate,
  formatDateHour: formatDateHour
}
