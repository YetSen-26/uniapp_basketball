<?php
return [
    'labels' => [
        'SystemMsg' => '系统消息',
        'system-msg' => '系统消息',
    ],
    'fields' => [
        'title' => '标题',
        'content' => '内容',
    ],
    'options' => [
    ],
];
