<video src="<?php echo $model->video_path?>" height="150" width="200" controls="controls"></video>
