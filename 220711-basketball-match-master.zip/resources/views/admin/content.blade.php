<?php echo $model->content?>
