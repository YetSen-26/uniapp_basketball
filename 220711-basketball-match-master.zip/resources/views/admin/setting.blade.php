<?php echo $model->value?>

