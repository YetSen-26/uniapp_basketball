<video src="<?php echo $model->video_path?>" height="250" width="100%" controls="controls"></video>
