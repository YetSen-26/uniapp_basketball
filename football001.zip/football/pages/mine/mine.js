// pages/mine/mine.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   info:{},
   team:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const app = getApp();
    const that =this;
    app.post('/api2/user/info',{}).then((res)=>{
      that.setData({info:res.data.data})
    })
    app.post('/api2/user/joined-teams',{page_size:1,page:1}).then((res)=>{
      const team =res.data.data.list[0]||false;
      this.setData({team:team})
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  go_edit(){
    wx.navigateTo({
      url: '/pages/edit_info/edit_info',
    })
  }
})