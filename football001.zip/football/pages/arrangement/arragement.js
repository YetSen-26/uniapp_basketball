// pages/arrangement/arragement.js
var app = getApp();
const {
  getAllTeam,
  getContest,
  getGroup,
  myUserId
} = require('../../api/detail.js');
Page({
  data: {
    cur: 1,
    time2: '',
    time1: '',
    userId:'',
    itemTtn:'报名',
    // 赛事
    page_size: 0,
    page: 0,
    total_pages: 0,
    total_items: 0,
    has_more: true,
    list: [{
      contest_group_id: 0,
      title: "山东大学篮球赛",
      cover_url: "/image/arragement/sdu_logo.png",
      sport_type: "string",
      attend_rule: "string",
      status: "string",
      display_time_begin: 1494431539619,
      display_time_end: 0,
      hidden: true,
      attend_person_count: 12,
    }],

    // 队伍
    teamsList: [],

    //约球
    contestList:[
      {
         contest_id: 0,
         contest_title: "string",
         attend_rule: "string",
         status: "string",
         sport_type: "string",
         attend_person_count: 0,
         display_time_begin: 0,
         display_time_end: 0
      }
    ],
    sign:1,
  },

  // 单击报名发送请求;
  handTap() {
    //获得队伍列表
    const that = this
      myUserId([], 1).then(res => {
     that.setData({
        userId: res.data
      })
    })
    wx.request({
      url: 'https://api.dxsyqb.cn:9999/api2/admin/contest-group/'+contestGroupId+'/participant/add-user/',
      data: {
        contestGroupId:that.data.list[0].contest_group_id,
        user_id:that.data.userId
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' 
      },
      method:'post',
      success: (res) => {
          // 將報名改為已報名
          that.setData({
            itemTtn: '已报名'
          })

      },
      fail: (res) => {
        that.setData({
          itemTtn: '请重试'
        })
      },
      complete: (res) => {
        that.setData({
          itemTtn: '请重试'
        })
      },
    })
  },

  // 获取用户id;
  user() {
        //获得队伍列表
        myUserId([], 1).then(res => {
          that.setData({
            userId: res.data
          })
        })
  },
  // 滚动切换标签样式
  switchTab: function (e) {
    this.setData({
      currentTab: e.detail.current
    });
    this.checkCor();
  },

  // 点击标题切换当前页时改变样式
  swichNav: function (e) {
    var cur = e.target.dataset.current;
    if (this.data.currentTaB == cur) {
      return false;
    } else {
      this.setData({
        currentTab: cur
      })
    }
  },


  onLoad: function () {

  },

  // onload代码页面准备完毕的时候会执行
  // 只要页面刷新或者进入此页面该方法都会执行一次
  onReady: function () {
    const that = this

    //获得比赛列表
    getGroup([], ["not_started", "ongoing"], 10, 1).then(res => {
      that.setData({
        list: res.list,
        cur: 1
      })
    })

    //获得队伍列表
    getAllTeam([], 20, 1).then(res => {
      that.setData({
        teamsList: res.list
      })
    })

    //获取约球（独立赛事)列表
    getContest([], ["not_started", "ongoing"], 10, 1).then(res => {
      that.setData({
        contestList: res.list,
        sign: 1
      })
    })
  },
  refresh: function () {
    const that = this;
    //this赋值变量到that，防止作用域不够
    that.setData({

    })
  },
  Unstart: function () {
    //获得近期比赛组列表
    const that = this;
    getGroup([], ["not_started", "ongoing"], 10, 1).then(res => {
      that.setData({
        list: res.list,
        cur: 1
      })
    })
  },

  Unstartfcontest: function () {
    //获得近期独立比赛列表
    const that = this;
    getContest([], ["over"], 10, 1).then(res => {
      that.setData({
        list: res.contestList,
        cur: 1
      })
    })
  },

  Finish: function () {
    //获得往期比赛组列表
    const that = this;
    const data = {
      name_query: [],
      status_query: ["over"],
      page_size: 10,
      page: 1
    }  
    getGroup(data).then(res => {
      that.setData({
        list: res.list,
        cur: 0
      })
    })
  },

  Finishcontest: function () {
    //获得往期比赛组列表
    const that = this;
    const data = {
      name_query: [],
      status_query: ["over"],
      page_size: 10,
      page: 1
    }  
    getContest(data).then(res => {
      that.setData({
        list: res.contestList,
        cur: 0
      })
    })
  },

  toDetail: function (e) {
    let id=JSON.stringify(e.currentTarget.dataset.item.contest_id);
    wx.navigateTo({
      url: '../competitionDetail/competitionDetail',
    })
  },

  toTeam: function () {
    wx.navigateTo({
      url: '../teamDetail/teamDetail',
    })
  },

  toContestDetail: function(){
    wx.navigateTo({
      url: '../com-standalone/com-standalone',
    })
  },

  toCreateTeam: function(){
    wx.navigateTo({
      url: '../createTeam/createTeam',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  footerTap: app.footerTap
})